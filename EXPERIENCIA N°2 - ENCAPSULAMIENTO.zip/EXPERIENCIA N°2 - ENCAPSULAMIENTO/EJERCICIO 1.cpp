/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <string>

using namespace std;

class Persona {
private:
    string nombre;
    int edad;
    string genero;

public:
    Persona(string name, int age, string gen) : nombre(name), edad(age), genero(gen) {}

    string getNombre() {
        return nombre;
    }

    void setNombre(string nuevoNombre) {
        nombre = nuevoNombre;
    }

    int getEdad() {
        return edad;
    }

    void setEdad(int nuevaEdad) {
        edad = nuevaEdad;
    }

    string getGenero() {
        return genero;
    }

    void setGenero(string nuevoGenero) {
        genero = nuevoGenero;
    }

    void saludar() {
        cout << "Nombre: " << nombre << ", Edad: " << edad << " Género: " << genero << endl;
    }
};

int main() {
    Persona persona1("Gian Piero", 24, "masculino");
    Persona persona2("Sandra", 20, "femenino");

    persona1.saludar();
    persona2.saludar(); 

    persona1.setNombre("Giancito");
    persona1.setEdad(24);
    persona1.setGenero("masculino");
    persona1.saludar();

    return 0;
}
