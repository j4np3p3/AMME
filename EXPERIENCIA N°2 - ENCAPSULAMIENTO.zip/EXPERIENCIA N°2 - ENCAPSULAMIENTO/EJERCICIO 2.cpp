/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <string>

using namespace std;

class CuentaBancaria {
private:
    string numeroCuenta;
    double saldo;

public:
    // Constructor
    CuentaBancaria(string numeroCuenta, double saldoInicial) : numeroCuenta(numeroCuenta), saldo(saldoInicial) {}

    // Métodos get
    string getNumeroCuenta() const {
        return numeroCuenta;
    }

    double getSaldo() const {
        return saldo;
    }

    // Métodos set
    void setNumeroCuenta(string nuevoNumeroCuenta) {
        numeroCuenta = nuevoNumeroCuenta;
    }

    void setSaldo(double nuevoSaldo) {
        saldo = nuevoSaldo;
    }

    // Método para mostrar información de la cuenta
    void informacion() {
        cout << "Número de cuenta: " << numeroCuenta << ", Saldo actual: S/." << saldo << endl;
    }
};

int main() {
    // Crear cuentas bancarias
    CuentaBancaria cuenta1("8375219467292414", 4560.0);
    CuentaBancaria cuenta2("2714158398455926", 1200.0);

    cuenta1.informacion();
    cuenta2.informacion(); 

    // Modificar la información de cuenta2
    cuenta2.setNumeroCuenta("4214764387837872");
    cuenta2.setSaldo(12000.0);
    cuenta2.informacion();

    return 0;
}
