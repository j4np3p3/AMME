/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <string>

using namespace std;

class CuentaBancaria {
private:
    string numeroCuenta;
    double saldo;

public:
    // Constructor
    CuentaBancaria(string numeroCuenta, double saldoInicial) : numeroCuenta(numeroCuenta), saldo(saldoInicial) {}

    // Métodos get
    string getNumeroCuenta() const {
        return numeroCuenta;
    }

    double getSaldo() const {
        return saldo;
    }

    // Métodos set
    void setNumeroCuenta(string nuevoNumeroCuenta) {
        numeroCuenta = nuevoNumeroCuenta;
    }

    void setSaldo(double nuevoSaldo) {
        saldo = nuevoSaldo;
    }

    // Método para mostrar información de la cuenta
    void informacion() {
        cout << "Número de cuenta: " << numeroCuenta << ", Saldo actual: S/." << saldo << endl;
    }
};

class Libro {
private:
    string titulo;
    string autor;
    string genero;

public:
    Libro(string titulo, string autor, string genero) : titulo(titulo), autor(autor), genero(genero) {}

    // Métodos get
    string getTitulo() const {
        return titulo;
    }

    string getAutor() const {
        return autor;
    }

    string getGenero() const {
        return genero;
    }

    // Métodos set
    void setTitulo(string nuevoTitulo) {
        titulo = nuevoTitulo;
    }

    void setAutor(string nuevoAutor) {
        autor = nuevoAutor;
    }

    void setGenero(string nuevoGenero) {
        genero = nuevoGenero;
    }

    // Método para mostrar información
    void informacion() const {
        cout << "Título: " << titulo << ", Autor: " << autor << ", Género: " << genero << endl;
    }
};

int main() {
    // Cuentas bancarias
    CuentaBancaria cuenta1("8375219467292414", 4560.0);
    CuentaBancaria cuenta2("2714158398455926", 1200.0);

    cuenta1.informacion();
    cuenta2.informacion(); 

    cuenta2.setNumeroCuenta("4214764387837872");
    cuenta2.setSaldo(12000.0);
    cuenta2.informacion();

    // Libros
    Libro libro1("El principito", "Antoine de Saint-Exupéry", "Literatura infantil");
    Libro libro2("Cien años de soledad", "Gabriel García Márquez", "Realismo mágico");

    libro1.informacion();
    libro2.informacion();
    
    libro2.setAutor("Mario Vargas Llosa");

    libro2.informacion();

    return 0;
}
