/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <string>

using namespace std;

class Factura {
private:
    string numeroFactura;
    string fechaEmision;
    double monto;

public:
    Factura(string numeroFactura, string fechaEmision, double monto) : numeroFactura(numeroFactura), fechaEmision(fechaEmision), monto(monto) {}

    // Métodos get
    string getNumeroFactura() const {
        return numeroFactura;
    }

    string getFechaEmision() const {
        return fechaEmision;
    }

    double getMonto() const {
        return monto;
    }

    // Métodos set
    void setNumeroFactura(string nuevoNumeroFactura) {
        numeroFactura = nuevoNumeroFactura;
    }

    void setFechaEmision(string nuevaFechaEmision) {
        fechaEmision = nuevaFechaEmision;
    }

    void setMonto(double nuevoMonto) {
        monto = nuevoMonto;
    }

    // Método para mostrar información
    void Informacion() const {
        cout << "Número de factura: " << numeroFactura << endl;
        cout << "Fecha de emisión: " << fechaEmision << endl;
        cout << "Monto: S/." << monto << endl;
    }
};

int main() {
    // Ejemplos
    Factura factura1("F27120", "2024-03-27", 1000.0);
    Factura factura2("F24681", "2024-03-37", 2500.0);

    cout << "Factura 1:" << endl;
    factura1.Informacion();
    cout << endl;

    cout << "Factura 2:" << endl;
    factura2.Informacion();
    cout << endl;

    // Factura 2 cambiada
    factura2.setMonto(3700.0);

    // Información nueva de factura 2
    cout << "Factura 2 actualizada:" << endl;
    factura2.Informacion();

    return 0;
}
